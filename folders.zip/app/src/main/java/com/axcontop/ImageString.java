package com.axcontop;

public class ImageString {

    public String icon_image = "";

}
