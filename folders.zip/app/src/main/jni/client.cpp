#include <list>
#include <vector>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <cmath>
#include "Tools/Includes/Logger.h"
#include "Tools/Includes/obfuscate.h"
#include "Tools/Includes/Utils.h"
#include "Tools/SOCKET/client.h"
#include "Tools/SOCKET/IncludeClient.h"
#include "Widgets/ImportWidgets.h"
#include "Tools/DrawTools/Draw.h"

static JavaVM* gJvm = nullptr;
static jobject gAppContext = nullptr;
static int s_lastMatchAlive = 0;
static int s_lastRemainingTimeSeconds = -1;

// ============================================================
//  VIP UI COLOR PALETTE (DARK BLUE Theme - 3D Lite)
// ============================================================
namespace VIPColors {
    Color bgDark      = Color(6, 12, 26, 255);      // deep navy
    Color bgMid       = Color(10, 20, 42, 255);     // dark blue
    Color bgLight     = Color(16, 32, 62, 255);     // lighter panel

    Color blue          = Color(37, 99, 235, 255);   // primary blue
    Color blueLight     = Color(96, 165, 250, 255);  // light blue
    Color blueGlow      = Color(59, 130, 246, 80);   // glow
    Color blueDark      = Color(30, 58, 138, 255);   // dark blue accent

    Color textPrimary = Color(239, 246, 255, 255);   // near white
    Color textMuted   = Color(148, 163, 184, 255);   // slate

    Color borderGlow  = Color(59, 130, 246, 180);
    Color shadow      = Color(0, 0, 0, 170);

    Color on  = Color(96, 165, 250, 255);
    Color off = Color(30, 41, 59, 255);

    Color tabActive   = Color(37, 99, 235, 255);
    Color tabInactive = Color(24, 34, 58, 255);
}

// ============================================================
//  20 COLOR PALETTE — SINGLE SOURCE OF TRUTH
// ============================================================
static Color GetPaletteColor(int idx) {
    switch (idx) {
        case 0:  return Color(255, 255, 255, 255); // 01 White
        case 1:  return Color(239, 68, 68, 255);   // 02 Red
        case 2:  return Color(34, 197, 94, 255);   // 03 Green
        case 3:  return Color(59, 130, 246, 255);  // 04 Blue
        case 4:  return Color(250, 204, 21, 255);  // 05 Yellow
        case 5:  return Color(249, 115, 22, 255);  // 06 Orange
        case 6:  return Color(168, 85, 247, 255);  // 07 Purple
        case 7:  return Color(255, 105, 180, 255); // 08 Pink
        case 8:  return Color(34, 211, 238, 255);  // 09 Cyan
        case 9:  return Color(255, 0, 255, 255);   // 10 Magenta
        case 10: return Color(16, 185, 129, 255);  // 11 Emerald
        case 11: return Color(0, 150, 136, 255);   // 12 Teal
        case 12: return Color(180, 255, 50, 255);  // 13 Lime
        case 13: return Color(212, 175, 55, 255);  // 14 Gold
        case 14: return Color(192, 192, 192, 255); // 15 Silver
        case 15: return Color(128, 0, 0, 255);     // 16 Maroon
        case 16: return Color(0, 0, 128, 255);     // 17 Navy
        case 17: return Color(220, 20, 60, 255);   // 18 Crimson
        case 18: return Color(143, 0, 255, 255);   // 19 Violet
        case 19: return Color(10, 80, 45, 255);    // 20 Dark Green
        default: return Color(255, 255, 255, 255); // fallback
    }
}

struct {
    bool ActivateAll = false;
    bool flyexploit = false;
    bool hidedamage = false;
    bool highfps = false;
    bool speedhackjoy = false;
    bool speedrun = false;
    bool invisiblePlayer = false;
    bool hitFly = false;
} MasterBool;

struct {
    bool enableAimbot = false;
    bool Aimkill = false;
    bool Aimkilltp = false;
    bool AimkillUp = false;
    bool AimSilent = false;
    bool speedhackjoy = false;
    bool upplayerx = false;
    float aimbotFOV = 0.0f;
    bool smartmove = false;
    bool Aimkillsend = false;
    bool AimkillSendAutoSwitch = false;
    bool AimkillSendCoverPull = false;
    bool SafeAimkill = false;
    float Lodaup = 0.0f;
    float lodaspeed = 0.0f;
} pAimbotPlayer;

struct {
    bool espLine = false;
    bool espBox = false;
    bool espDistance = false;
    bool espHealth = false;
    bool espDrawFov = false;
    Color espColor = Color::White();
    bool espNickName = false;
    int lineType = 0;
    int boxType = 0;
    int selectedColorIndex = 0; // 0-19 → palette index
} pEspPlayer;

struct {
    bool silentkill = false;
    bool UpPlayer = false;
    bool aimtracking = false;
    bool teleportenemytome = false;
    bool AutoRevive = false;
    bool autoexecute = false;
    bool resetguest = false;
    bool autoteleport = false;
    bool speedrun = false;
    bool snapfly = false;
    bool fastfiremax = false;
    bool fastfireauto = false;
    bool fastfuck = false;
    bool noreloadfck = false;
    bool autofire = false;
    bool autofireslow = false;
    bool autojump = false;
    bool noDelay = false;
    bool autoSwitchEnabled = true;
    bool enable3DBackground = true;
} pMemoryTools;

using namespace std;

// ============================================================
//  GLOBAL 3D BACKGROUND STATE (DARK BLUE CUBES)
// ============================================================
struct Cube3D {
    float x, y, z;
    float angle;
    float speed;
    float size;
    Color color;
};

static std::vector<Cube3D> g_3dCubes;
static float g_3dTime = 0.0f;
static bool g_3dInit = false;

static void Init3DBackground() {
    if (g_3dInit) return;
    g_3dCubes.clear();
    for (int i = 0; i < 12; ++i) {
        Cube3D cube;
        cube.x = (float)(rand() % 1080);
        cube.y = (float)(rand() % 1920);
        cube.z = (float)(rand() % 100) / 100.0f;
        cube.angle = (float)(rand() % 360);
        cube.speed = 0.2f + (float)(rand() % 100) / 100.0f * 0.8f;
        cube.size = 15.0f + (float)(rand() % 40);

        // DARK BLUE 3D CUBE COLORS — low R, low G, high B
        cube.color = Color(
            10 + rand() % 30,    // R  (10–40)
            30 + rand() % 60,    // G  (30–90)
            120 + rand() % 80,   // B  (120–200)
            30 + rand() % 40     // A  (30–70)
        );
        g_3dCubes.push_back(cube);
    }
    g_3dInit = true;
}

static void Draw3DCube(DrawView& draw, float cx, float cy, float size, float angle, Color color) {
    float half = size * 0.5f;
    float cosA = cosf(angle);
    float sinA = sinf(angle);

    float corners[8][2] = {
        {-half, -half}, { half, -half}, { half,  half}, {-half,  half},
        {-half + size*0.3f, -half - size*0.3f},
        { half + size*0.3f, -half - size*0.3f},
        { half + size*0.3f,  half - size*0.3f},
        {-half + size*0.3f,  half - size*0.3f}
    };

    for (int i = 0; i < 8; ++i) {
        float rx = corners[i][0] * cosA - corners[i][1] * sinA;
        float ry = corners[i][0] * sinA + corners[i][1] * cosA;
        corners[i][0] = rx + cx;
        corners[i][1] = ry + cy;
    }

    draw.DrawLine(color, 1, Vector2(corners[0][0], corners[0][1]), Vector2(corners[1][0], corners[1][1]));
    draw.DrawLine(color, 1, Vector2(corners[1][0], corners[1][1]), Vector2(corners[2][0], corners[2][1]));
    draw.DrawLine(color, 1, Vector2(corners[2][0], corners[2][1]), Vector2(corners[3][0], corners[3][1]));
    draw.DrawLine(color, 1, Vector2(corners[3][0], corners[3][1]), Vector2(corners[0][0], corners[0][1]));

    draw.DrawLine(color, 1, Vector2(corners[4][0], corners[4][1]), Vector2(corners[5][0], corners[5][1]));
    draw.DrawLine(color, 1, Vector2(corners[5][0], corners[5][1]), Vector2(corners[6][0], corners[6][1]));
    draw.DrawLine(color, 1, Vector2(corners[6][0], corners[6][1]), Vector2(corners[7][0], corners[7][1]));
    draw.DrawLine(color, 1, Vector2(corners[7][0], corners[7][1]), Vector2(corners[4][0], corners[4][1]));

    draw.DrawLine(color, 1, Vector2(corners[0][0], corners[0][1]), Vector2(corners[4][0], corners[4][1]));
    draw.DrawLine(color, 1, Vector2(corners[1][0], corners[1][1]), Vector2(corners[5][0], corners[5][1]));
    draw.DrawLine(color, 1, Vector2(corners[2][0], corners[2][1]), Vector2(corners[6][0], corners[6][1]));
    draw.DrawLine(color, 1, Vector2(corners[3][0], corners[3][1]), Vector2(corners[7][0], corners[7][1]));
}

static void DrawGridBackground(DrawView& draw, float w, float h) {
    // DARK BLUE GRID
    Color gridColor(59, 130, 246, 18);
    Color gridColorBright(59, 130, 246, 42);

    float horizon = h * 0.6f;

    for (int i = 1; i <= 12; ++i) {
        float t = (float)i / 12.0f;
        float y = horizon + (h - horizon) * (t * t);
        Color c = (i % 3 == 0) ? gridColorBright : gridColor;
        draw.DrawLine(c, 1, Vector2(0, y), Vector2(w, y));
    }

    float vpX = w * 0.5f;
    for (int i = -10; i <= 10; ++i) {
        float xBottom = vpX + i * (w / 10.0f);
        Color c = (i % 3 == 0) ? gridColorBright : gridColor;
        draw.DrawLine(c, 1, Vector2(vpX, horizon), Vector2(xBottom, h));
    }
}

extern "C"
JNIEXPORT jintArray JNICALL
Java_com_axcontop_Menu_getMatchTimerStatus(JNIEnv *env, jclass clazz) {
    jintArray arr = env->NewIntArray(2);
    if (!arr) return nullptr;
    jint buf[2] = { (jint)s_lastMatchAlive, (jint)s_lastRemainingTimeSeconds };
    env->SetIntArrayRegion(arr, 0, 2, buf);
    return arr;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_axcontop_Menu_imageBase64(JNIEnv *env, jclass thiz) {
    return env->NewStringUTF(OBFUSCATE(""));
}

extern "C"
JNIEXPORT void JNICALL
Java_com_axcontop_Menu_Init(JNIEnv *env, jclass thiz, jobject context) {
    startClient();
    Init3DBackground();
}

float fovRadius = 104;

extern "C"
JNIEXPORT void JNICALL
Java_com_axcontop_Menu_Functions(JNIEnv *env, jclass clazz) {
    Widget widget = Widget(env);

    // --------------------------------------------------------
    //  [ AIM ] TAB
    // --------------------------------------------------------
    widget.Tab(OBFUSCATE("★ AIM ★"));
    widget.Switch(OBFUSCATE("Enable Functions"), 102);
    widget.Switch(OBFUSCATE("Brutal Aimkill"), 105);
    widget.Switch(OBFUSCATE("Aimkill Send Cover Pull"), 107);
    widget.Switch(OBFUSCATE("Safe Aimkill Cover"), 110);
    widget.Switch(OBFUSCATE("Fast Auto Switch"), 106);
    widget.Switch(OBFUSCATE("Hide Damage"), 527);
    widget.Switch(OBFUSCATE("Silent Aim"), 889);
    widget.Switch(OBFUSCATE("Pull Enemy From Cover"), 509);
    widget.Switch(OBFUSCATE("AimLock"), 34834);
    widget.Switch(OBFUSCATE("Target List Overlay"), 526);
    widget.Switch(OBFUSCATE("Lock Target"), 523);
    widget.SeekBar(OBFUSCATE("AimFov"), 1000, 1000, "x", 104);

    // --------------------------------------------------------
    //  [ ESP ] TAB
    // --------------------------------------------------------
    widget.Tab(OBFUSCATE("◆ ESP ◆"));
    widget.Switch(OBFUSCATE("ESP LINE"), 1);
    widget.Switch(OBFUSCATE("ESP BOX"), 2);
    widget.Switch(OBFUSCATE("ESP HEALTH"), 3);
    widget.Switch(OBFUSCATE("ESP NAME"), 9);
    widget.Switch(OBFUSCATE("ESP DISTANCE"), 4);
    widget.Switch(OBFUSCATE("DRAW FOV"), 16);
    widget.SeekBar(OBFUSCATE("COLOR (0-9)"), 9, 0, OBFUSCATE("Color"), 5);
    widget.SeekBar(OBFUSCATE("COLOR 20 PALETTE"), 20, 0, OBFUSCATE("Color"), 8021);

    // --------------------------------------------------------
    //  [ MISC ] TAB
    // --------------------------------------------------------
    widget.Tab(OBFUSCATE("⚡ MISC ⚡"));
    widget.Switch(OBFUSCATE("FLYHACK [MINI]"), 111);
    widget.Switch(OBFUSCATE("FLY EXPLOIT"), 1080);
    widget.Switch(OBFUSCATE("TELEPORT MARK"), 56578);
    widget.Switch(OBFUSCATE("TELEPORT ENEMY"), 5657899);
    widget.Switch(OBFUSCATE("AUTO REVIVE"), 7896);
    widget.Switch(OBFUSCATE("FAST FIRE [ALLGUN]"), 1046);
    widget.Switch(OBFUSCATE("AUTO JUMP"), 522);
    widget.Switch(OBFUSCATE("DASH SPEED"), 507);
    widget.Switch(OBFUSCATE("JOYSTICK SPEED"), 114);
    widget.Switch(OBFUSCATE("SPEED TIMER"), 517);
    widget.Switch(OBFUSCATE("RESET GUEST"), 12);
    widget.Switch(OBFUSCATE("HIGH FPS"), 529);
    widget.Switch(OBFUSCATE("FAST FIRE MAX"), 515);
    widget.Switch(OBFUSCATE("FAST FIRE AUTO"), 516);
    widget.Switch(OBFUSCATE("FAST RELOAD"), 519);

    // --------------------------------------------------------
    //  [ VISUAL ] TAB
    // --------------------------------------------------------
    widget.Tab(OBFUSCATE("◈ VISUAL ◈"));
    widget.Switch(OBFUSCATE("INVISIBLE PLAYER - MAINTAINANCE"), 530);
    widget.Switch(OBFUSCATE("HIT FLY - MAINTAINANCE"), 531);
    widget.Switch(OBFUSCATE("3D LITE BACKGROUND"), 7777);

    // --------------------------------------------------------
    //  [ SETTING ] TAB
    // --------------------------------------------------------
    widget.Tab(OBFUSCATE("⚙ SETTING ⚙"));
    widget.Switch(OBFUSCATE("INVALID MATCH TIMER"), 6003);
    widget.SeekBar(OBFUSCATE("COLOR PICKER (0-20)"), 20, 0, OBFUSCATE("Color"), 8021);

    widget.Switch(OBFUSCATE("01 · White"),      8001);
    widget.Switch(OBFUSCATE("02 · Red"),        8002);
    widget.Switch(OBFUSCATE("03 · Green"),      8003);
    widget.Switch(OBFUSCATE("04 · Blue"),       8004);
    widget.Switch(OBFUSCATE("05 · Yellow"),     8005);
    widget.Switch(OBFUSCATE("06 · Orange"),     8006);
    widget.Switch(OBFUSCATE("07 · Purple"),     8007);
    widget.Switch(OBFUSCATE("08 · Pink"),       8008);
    widget.Switch(OBFUSCATE("09 · Cyan"),       8009);
    widget.Switch(OBFUSCATE("10 · Magenta"),    8010);
    widget.Switch(OBFUSCATE("11 · Emerald"),    8011);
    widget.Switch(OBFUSCATE("12 · Teal"),       8012);
    widget.Switch(OBFUSCATE("13 · Lime"),       8013);
    widget.Switch(OBFUSCATE("14 · Gold"),       8014);
    widget.Switch(OBFUSCATE("15 · Silver"),     8015);
    widget.Switch(OBFUSCATE("16 · Maroon"),     8016);
    widget.Switch(OBFUSCATE("17 · Navy"),       8017);
    widget.Switch(OBFUSCATE("18 · Crimson"),    8018);
    widget.Switch(OBFUSCATE("19 · Violet"),     8019);
    widget.Switch(OBFUSCATE("20 · Dark Green"), 8020);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_axcontop_Menu_ChangesID(JNIEnv *env, jclass clazz, jint id, jint value) {
    switch (id) {
        case 889:
            pMemoryTools.silentkill = (value == 1);
            SendFeatuere(889, pMemoryTools.silentkill);
            break;
        case 34834:
            pMemoryTools.aimtracking = (value == 1);
            SendFeatuere(34834, pMemoryTools.aimtracking);
            break;
        case 7896:
            pMemoryTools.AutoRevive = (value == 1);
            SendFeatuere(7896, pMemoryTools.AutoRevive);
            break;
        case 7898:
            pMemoryTools.autoexecute = (value == 1);
            SendFeatuere(7898, pMemoryTools.autoexecute);
            break;
        case 12:
            pMemoryTools.resetguest = (value == 1);
            SendFeatuere(12, pMemoryTools.resetguest);
            break;
        case 102:
            MasterBool.ActivateAll = (value == 1);
            SendFeatuere(3, MasterBool.ActivateAll);
            break;
        case 100:
            pAimbotPlayer.Aimkill = (value == 1);
            SendFeatuere(100, pAimbotPlayer.Aimkill);
            break;
        case 105:
            pAimbotPlayer.Aimkillsend = (value == 1);
            SendFeatuere(1044, pAimbotPlayer.Aimkillsend);
            break;
        case 106:
            pAimbotPlayer.AimkillSendAutoSwitch = (value == 1);
            SendFeatuere(1047, pAimbotPlayer.AimkillSendAutoSwitch);
            break;
        case 507:
            pMemoryTools.speedrun = (value != 0);
            SendFeatuere(507, pMemoryTools.speedrun);
            break;
        case 107:
            pAimbotPlayer.AimkillSendCoverPull = (value == 1);
            SendFeatuere(1048, pAimbotPlayer.AimkillSendCoverPull);
            break;
        case 110:
            pAimbotPlayer.SafeAimkill = (value == 1);
            SendFeatuere(1049, pAimbotPlayer.SafeAimkill);
            break;
        case 523:
            SendFeatuere(523, value == 1);
            break;
        case 527:
            MasterBool.hidedamage = (value == 1);
            SendFeatuere(527, value == 1);
            break;
        case 529:
            MasterBool.highfps = (value == 1);
            SendFeatuere(529, value == 1);
            break;
        case 530:
            MasterBool.invisiblePlayer = (value == 1);
            SendFeatuere(530, MasterBool.invisiblePlayer);
            break;
        case 531:
            MasterBool.hitFly = (value == 1);
            SendFeatuere(531, MasterBool.hitFly);
            break;
        case 114:
            MasterBool.speedhackjoy = (value == 1);
            SendFeatuere(15, value == 1);
            break;
        case 1080:
            MasterBool.flyexploit = !MasterBool.flyexploit;
            SendFeatuere(1080, MasterBool.flyexploit);
            break;
        case 111:
            pAimbotPlayer.AimkillUp = (value == 1);
            SendFeatuere(5657, pAimbotPlayer.AimkillUp);
            break;
        case 104:
            pAimbotPlayer.aimbotFOV = (float)value;
            SendFOV(104, (float)value);
            break;
        case 1043:
            pAimbotPlayer.lodaspeed = (float)value;
            SendFOV(1043, (float)value);
            break;
        case 1044: SendFeatuere(1044, (value == 1)); break;
        case 1047: SendFeatuere(1047, (value == 1)); break;
        case 1048: SendFeatuere(1048, (value == 1)); break;
        case 1049: SendFeatuere(1049, (value == 1)); break;
        case 1045: SendFeatuere(1045, (value == 1)); break;
        case 1046: SendFeatuere(1046, (value == 1)); break;
        case 5001:
            pMemoryTools.snapfly = (value == 1);
            SendFeatuere(5001, pMemoryTools.snapfly);
            break;
        case 1: pEspPlayer.espLine = (value == 1); break;
        case 112:
            pAimbotPlayer.AimSilent = (value == 1);
            SendFeatuere(889, pAimbotPlayer.AimSilent);
            break;
        case 2: pEspPlayer.espBox = (value == 1); break;
        case 3: pEspPlayer.espHealth = (value == 1); break;
        case 9: pEspPlayer.espNickName = (value == 1); break;
        case 4: pEspPlayer.espDistance = (value == 1); break;
        case 16: pEspPlayer.espDrawFov = (value == 1); break;

        case 5:
            pEspPlayer.selectedColorIndex = value;
            pEspPlayer.espColor = GetPaletteColor(value);
            break;

        case 8021:
            if (value < 0) value = 0;
            if (value > 19) value = 19;
            pEspPlayer.selectedColorIndex = value;
            pEspPlayer.espColor = GetPaletteColor(value);
            break;

        case 8001: if (value == 1) { pEspPlayer.selectedColorIndex = 0;  pEspPlayer.espColor = GetPaletteColor(0);  } break;
        case 8002: if (value == 1) { pEspPlayer.selectedColorIndex = 1;  pEspPlayer.espColor = GetPaletteColor(1);  } break;
        case 8003: if (value == 1) { pEspPlayer.selectedColorIndex = 2;  pEspPlayer.espColor = GetPaletteColor(2);  } break;
        case 8004: if (value == 1) { pEspPlayer.selectedColorIndex = 3;  pEspPlayer.espColor = GetPaletteColor(3);  } break;
        case 8005: if (value == 1) { pEspPlayer.selectedColorIndex = 4;  pEspPlayer.espColor = GetPaletteColor(4);  } break;
        case 8006: if (value == 1) { pEspPlayer.selectedColorIndex = 5;  pEspPlayer.espColor = GetPaletteColor(5);  } break;
        case 8007: if (value == 1) { pEspPlayer.selectedColorIndex = 6;  pEspPlayer.espColor = GetPaletteColor(6);  } break;
        case 8008: if (value == 1) { pEspPlayer.selectedColorIndex = 7;  pEspPlayer.espColor = GetPaletteColor(7);  } break;
        case 8009: if (value == 1) { pEspPlayer.selectedColorIndex = 8;  pEspPlayer.espColor = GetPaletteColor(8);  } break;
        case 8010: if (value == 1) { pEspPlayer.selectedColorIndex = 9;  pEspPlayer.espColor = GetPaletteColor(9);  } break;
        case 8011: if (value == 1) { pEspPlayer.selectedColorIndex = 10; pEspPlayer.espColor = GetPaletteColor(10); } break;
        case 8012: if (value == 1) { pEspPlayer.selectedColorIndex = 11; pEspPlayer.espColor = GetPaletteColor(11); } break;
        case 8013: if (value == 1) { pEspPlayer.selectedColorIndex = 12; pEspPlayer.espColor = GetPaletteColor(12); } break;
        case 8014: if (value == 1) { pEspPlayer.selectedColorIndex = 13; pEspPlayer.espColor = GetPaletteColor(13); } break;
        case 8015: if (value == 1) { pEspPlayer.selectedColorIndex = 14; pEspPlayer.espColor = GetPaletteColor(14); } break;
        case 8016: if (value == 1) { pEspPlayer.selectedColorIndex = 15; pEspPlayer.espColor = GetPaletteColor(15); } break;
        case 8017: if (value == 1) { pEspPlayer.selectedColorIndex = 16; pEspPlayer.espColor = GetPaletteColor(16); } break;
        case 8018: if (value == 1) { pEspPlayer.selectedColorIndex = 17; pEspPlayer.espColor = GetPaletteColor(17); } break;
        case 8019: if (value == 1) { pEspPlayer.selectedColorIndex = 18; pEspPlayer.espColor = GetPaletteColor(18); } break;
        case 8020: if (value == 1) { pEspPlayer.selectedColorIndex = 19; pEspPlayer.espColor = GetPaletteColor(19); } break;

        case 6: pEspPlayer.lineType = value; break;
        case 7: pEspPlayer.boxType = value; break;

        case 56578:
            pMemoryTools.teleportenemytome = !pMemoryTools.teleportenemytome;
            SendFeatuere(56578, pMemoryTools.teleportenemytome);
            break;
        case 5657899:
            pMemoryTools.autoteleport = !pMemoryTools.autoteleport;
            SendFeatuere(5657899, pMemoryTools.autoteleport);
            break;
        case 517:
            pMemoryTools.noDelay = (value == 1);
            SendFeatuere(517, pMemoryTools.noDelay);
            break;
        case 509:
            pAimbotPlayer.smartmove = !pAimbotPlayer.smartmove;
            SendFeatuere(509, pAimbotPlayer.smartmove);
            break;
        case 515:
            pMemoryTools.fastfiremax = !pMemoryTools.fastfiremax;
            SendFeatuere(515, pMemoryTools.fastfiremax);
            break;
        case 516:
            pMemoryTools.fastfireauto = !pMemoryTools.fastfireauto;
            SendFeatuere(516, pMemoryTools.fastfireauto);
            break;
        case 518:
            pMemoryTools.fastfuck = !pMemoryTools.fastfuck;
            SendFeatuere(518, pMemoryTools.fastfuck);
            break;
        case 519:
            pMemoryTools.noreloadfck = !pMemoryTools.noreloadfck;
            SendFeatuere(519, pMemoryTools.noreloadfck);
            break;
        case 520:
            pMemoryTools.autofire = !pMemoryTools.autofire;
            if (pMemoryTools.autofire) pMemoryTools.noreloadfck = true;
            SendFeatuere(520, pMemoryTools.autofire);
            break;
        case 524:
            pMemoryTools.autoSwitchEnabled = !pMemoryTools.autoSwitchEnabled;
            SendFeatuere(524, pMemoryTools.autoSwitchEnabled);
            break;
        case 521:
            pMemoryTools.autofireslow = !pMemoryTools.autofireslow;
            if (pMemoryTools.autofireslow) {
                pMemoryTools.fastfiremax = true;
                pMemoryTools.noreloadfck = true;
            }
            SendFeatuere(521, pMemoryTools.autofireslow);
            break;
        case 522:
            pMemoryTools.autojump = (value == 1);
            SendFeatuere(522, pMemoryTools.autojump);
            break;
        case 528:
            SendFeatuere(528, (value == 1));
            break;
        case 526:
            jclass CMenu = env->FindClass("com/axcontop/Menu");
            jmethodID MToggle = env->GetStaticMethodID(CMenu, "toggleTargetListStatic", "()V");
            env->CallStaticVoidMethod(CMenu, MToggle);
            break;

        case 7777:
            pMemoryTools.enable3DBackground = (value == 1);
            break;
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_com_axcontop_Menu_LockPlayer(JNIEnv *env, jclass clazz, jlong ptr) {
    LockSpecificPlayer((uint64_t)ptr);
}

extern "C"
JNIEXPORT jobjectArray JNICALL
Java_com_axcontop_Menu_getEnemyList(JNIEnv *env, jclass clazz) {
    Response response = getData(1920, 1080);
    if (!response.Success || response.PlayerCount == 0) return nullptr;

    jclass cls = env->FindClass("java/lang/String");
    jobjectArray array = env->NewObjectArray(response.PlayerCount * 2, cls, nullptr);

    for (int i = 0; i < response.PlayerCount; i++) {
        char info[256];
        sprintf(info, "%s", response.Players[i].name);
        env->SetObjectArrayElement(array, i * 2, env->NewStringUTF(info));

        char ptrStr[64];
        sprintf(ptrStr, "%llu", response.Players[i].playerPtr);
        env->SetObjectArrayElement(array, i * 2 + 1, env->NewStringUTF(ptrStr));
    }
    return array;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_axcontop_Menu_OnDrawLoad(JNIEnv *env, jclass clazz, jobject draw_view, jobject canvas) {
    DrawView draw = DrawView(env, draw_view, canvas);
    if (!draw.isValid()) return;

    float screenW = draw.getWidth();
    float screenH = draw.getHeight();

    // ============================================================
    //  3D LITE BACKGROUND (DARK BLUE)
    // ============================================================
    if (pMemoryTools.enable3DBackground) {
        Init3DBackground();
        g_3dTime += 0.016f;

        DrawGridBackground(draw, screenW, screenH);

        for (auto& cube : g_3dCubes) {
            cube.angle += cube.speed * 0.01f;
            cube.y -= cube.speed * 0.3f;

            if (cube.y < -50) {
                cube.y = screenH + 50;
                cube.x = (float)(rand() % (int)screenW);
            }

            Draw3DCube(draw, cube.x, cube.y, cube.size, cube.angle, cube.color);
        }
    }

    // ============================================================
    //  ESP RENDERING
    // ============================================================
    Response response = getData(screenW, screenH);
    s_lastMatchAlive = response.matchAlive;
    s_lastRemainingTimeSeconds = response.remainingTimeSeconds;
    if (!response.Success) return;

    Color espColor = pEspPlayer.espColor;

    if (pEspPlayer.espDrawFov) {
        float centerX = screenW / 2.0f;
        float centerY = screenH / 2.0f;
        draw.DrawCircle(espColor, 1, Vector2(centerX, centerY), pAimbotPlayer.aimbotFOV);
    }

    for (int i = 0; i < response.PlayerCount; ++i) {
        PlayerData data = response.Players[i];
        Vector3 HeadLoc = data.headPosition;
        Vector3 PesLoc  = data.bottomPlayerPosition;

        if (data.distance <= 1.0f || data.distance > 400.0f) continue;
        if (data.health <= 0) continue;
        if (HeadLoc.X == 0 && HeadLoc.Y == 0) continue;

        float headX = HeadLoc.X;
        float headY = screenH - HeadLoc.Y;

        if (headX < -100 || headX > screenW + 100 || headY < -100 || headY > screenH + 100) continue;

        float distance = data.distance;
        bool IsCaido = data.isDieing;

        float rawHeight = fabsf(HeadLoc.Y - PesLoc.Y);
        if (rawHeight < 2.0f) rawHeight = 50.0f;

        float scale = std::max(0.4f, std::min(1.0f, 300.0f / distance));
        float boxHeight = rawHeight * scale;
        float boxWidth  = boxHeight * 0.55f;

        Rect PlayerRect(headX - (boxWidth / 2.0f), headY, boxWidth, boxHeight);

        if (pEspPlayer.espLine) {
            Vector2 lineStart(screenW / 2.0f, 80.0f);
            Vector2 lineEnd(headX, headY);
            draw.DrawLine(IsCaido ? Color::Red() : espColor, 1, lineStart, lineEnd);
        }

        if (pEspPlayer.espBox && !IsCaido) {
            draw.DrawBox(espColor, 1, PlayerRect);
        }

        if ((pEspPlayer.espNickName || pEspPlayer.espDistance) && !IsCaido) {
            char nameStr[256] = "";
            char distanceStr[32] = "";
            if (pEspPlayer.espDistance) sprintf(distanceStr, "%dm", (int)data.distance);
            if (pEspPlayer.espNickName && data.name[0] != '\0') strcpy(nameStr, data.name);

            Vector2 labelPos(PlayerRect.x + (PlayerRect.w / 2.0f), PlayerRect.y - 10.0f);
            draw.DrawNameWithCard(VIPColors::textPrimary, nameStr, distanceStr, labelPos, 11);
        }

        if (pEspPlayer.espHealth && !IsCaido) {
            Vector2 healthBarPos(PlayerRect.x - 6.0f, PlayerRect.y);
            draw.DrawVerticalHealthBar(healthBarPos, boxHeight, 100.0f, data.health);
        }
    }
}